# Statistics(mean,median,mode) :
A PyPI package that can be used to find the mean,median,and mode of the given numbers in a list. 

# Installation :
Run the following to install:

'''cmd
pip install Statistics formulae
'''

# Team :
## Contributor : Vishal Kanna AJk
## Mentor      : Vidhya Lakshmi